/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackQueueHash;

import java.util.ArrayDeque;
import java.util.Iterator;

/**
 *
 * @author "Soujanya Janapatla";
 */
class AStack<E> {
    private ArrayDeque<E> cardStack;

    public AStack() {
        cardStack = new ArrayDeque<E>();
    }
    
    /**
     * method to push elements to Stack
     *
     * @param element parameter of type E
     */
    public void push(E element) {
        cardStack.push(element);
    }

    /**
     * method to pop elements from stack
     *
     * @return returns elements of type E
     */
    public E pop() {
        return cardStack.pop();
    }

    /**
     * method that retrieves the top element in stack
     *
     * @return element of type E
     */
    public E peek() {
        return cardStack.peek();
    }

    /**
     * method that gives stack size
     *
     * @return size of type int
     */
    public int size() {
        return cardStack.size();
    }

    /**
     * method to know if stack is empty or not
     *
     * @return Boolean value
     */
    public boolean isEmpty() {
        return cardStack.isEmpty();
    }

    /**
     * Iterator method on stack
     * @return elements of type iterator
     */
    public Iterator<E> iterator() {
        return cardStack.iterator();
    }
}
