/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackQueueHash;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.LinkedBlockingQueue;

/**
 *
 * @author "Soujanya Janapatla";
 */
public class PlayerDriver {

    /**
     * Since the class includes file reading operation it might throw some exception
     * @param args all the inputs
     * @throws FileNotFoundException exception
     */
    public static void main(String args[]) throws FileNotFoundException{
        //Declare and initialize a scanner object to read from the file "inputFile.txt"
        int capacity = 10, playerCount = 1, gameRounds = 3;
        int[] playerScore = new int[capacity];
        Scanner myScanner = new Scanner(new File("cardInputFile.txt"));
        AStack<Card> cards = new AStack<Card>();
        TreeMap<String,Integer> scoreDetails = new TreeMap<String,Integer>();
        
        LinkedBlockingQueue<Player> queue = new LinkedBlockingQueue<Player>(capacity);
	
        //While inputFile.txt has more data(While loop starts here) {
        while(myScanner.hasNext()){
            //Read in the data.
            int number = myScanner.nextInt();
            myScanner.nextLine();
            String suite = myScanner.nextLine();
            
            Card card = new Card(number, suite);
            cards.push(card);
            //Add the card object to CardsArray object
        }
        
        while(queue.remainingCapacity()!= 0){
            queue.add(new Player("Player "+ playerCount));
            playerCount++;
        }
        System.out.println("\n============= Cards Picked by Players =============");
        for (int i = 0; i < gameRounds; i++) {
            System.out.println("------------------- Game Round "+(i+1)+"-------------------\n");
            drawCradsFromDeck(queue, cards, scoreDetails);
        }
        TreeMap sortedMap = sortByValue(scoreDetails);
        //System.out.println("Final size "+ sortedMap.size());
        System.out.println("Final Ranked List of players along with score: ");
        
        // Get a set of the entries
        Set newSet = sortedMap.entrySet();

        // Get an iterator
        Iterator sortedList = newSet.iterator();
        //System.out.println(sortedList.);

        // Display elements
        while(sortedList.hasNext()) {
            Map.Entry record = (Map.Entry)sortedList.next();
            System.out.print(record.getKey() + "\t");
            System.out.println("Score : "+record.getValue());
            //System.out.println(iterate);
        } 
    }
    //public static void drawCradsFromDeck(LinkedBlockingQueue<Player> queue, AStack<Card> cards, TreeMap<String, Integer> scoreDetails){

    /**
     * This method takes player object(LinkedList), Card stack and TreeMap to store the score and details of the player
     * @param queue collection of players
     * @param cards collection of cards in stack
     * @param scoreDetails score details of players
     */
    public static void drawCradsFromDeck(LinkedBlockingQueue<Player> queue, AStack<Card> cards, TreeMap<String, Integer> scoreDetails){
        //System.out.println("Player size : "+queue.size());
        Iterator<Player> player = queue.iterator();
        
        while(player.hasNext()){
            Player person = player.next();
            Card c = cards.pop();
            Integer score = scoreDetails.get(person.getName());
            if(score == null){
                addScore(scoreDetails, person.getName(), c.getNumber());
            } else {
                Integer scoreTemp = scoreDetails.get(person.getName()) + c.getNumber();
                //System.out.println(person.getName()+" "+scoreTemp);
                scoreDetails.put(person.getName(), scoreTemp);
            }
            System.out.println("Player Name: "+person.getName()+"\t ID: "+person.getId() +" \nCard value: "+c.getNumber()+"\t Card type: "+c.getSuit()+"\tScore : "+ scoreDetails.get(person.getName())+"\n");//
        }
    }
    
    /**
     * This method adds the score card every time the player picks the card
     * @param scoreList TreeMap object
     * @param name String
     * @param score Integer
     */
    public static void addScore(TreeMap<String, Integer> scoreList, String name, Integer score){
        scoreList.put(name, score);
    }
    
    /**
     * This function sorts the TreeMap from high to low score
     * @param unsortedMap object to store collection
     * @return sortedMap from highest score to lowest
     */
    public static TreeMap<String, Integer> sortByValue(TreeMap<String, Integer> unsortedMap) {
        //System.out.println("UnSorted Map Size : "+unsortedMap.size());
        TreeMap<String, Integer> sortedMap = new TreeMap(new ValueComparator(unsortedMap));
        sortedMap.putAll(unsortedMap);
        //System.out.println("Sorted Map size: "+sortedMap.size());
        return sortedMap;
    }
   
}

class ValueComparator implements Comparator {
    TreeMap<String, Integer> map;

    public ValueComparator(TreeMap<String, Integer> map) {
        this.map = map;
    }

    public int compare(Object keyA, Object keyB) {
        Comparable valueA = (Comparable) map.get(keyA);
        Comparable valueB = (Comparable) map.get(keyB);
        return valueB.compareTo(valueA);
    }
}

