/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mapSetList;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author "Soujanya Janapatla";
 */
public class Itinerary {
    private LinkedList<Travel> travelList;
    Set<Travel> formattedList = new HashSet<Travel>();
    LinkedList<String> vowles = new LinkedList<String>();    
    Set<String> consonents = new HashSet<String>();
    Set<String> startsWithHotel = new HashSet<String>();
    Set<String> endsWithNList = new HashSet<String>();//
    Set<String> travelModeFlight = new HashSet<String>();
    TreeMap<String, LinkedList<String>> stringStatistics = new TreeMap<String, LinkedList<String>>();

    /**
     * No parameter constructor for Itinerary class initializing the LinedList of type Travel
     */
    public Itinerary() {
        this.travelList = new LinkedList<Travel>();
    }
    
    /**
     * Since this class perform file input output its recommended to use Exception handlers
     * @throws FileNotFoundException Input Exception
     */
    public void addLocations()throws FileNotFoundException {
        //System.out.println("Hi");
        Scanner scan = new Scanner(new File("itinerary.txt"));
        int duration, distance,travelers; //How much time can be spent to look around
        double cost;
        String destination, place, description, accomodation, accomodationType, stayCostPerday, activity, food, travelMode, numberOfTravelers, temp, placeOne, placeTwo; //Location name
        String capitalizeAccommodation;
        while(scan.hasNext()){
            duration = scan.nextInt();
            //scan.nextLine();
            //System.out.println("duration : "+duration);
            placeOne = scan.next();
            placeTwo = scan.next();
            accomodation = placeOne.concat(" ")+placeTwo;
            capitalizeAccommodation = toCapitalizeString(accomodation);
            //System.out.println("place :" +accomodation);
            cost = scan.nextDouble();
            //System.out.println("cost : " + cost);

            numberOfTravelers = scan.next();
            temp = numberOfTravelers.replace("daycount", "");
            travelers = Integer.parseInt(temp);
            //System.out.println("numberOfTravelers : "+travelers);

            travelMode = scan.next();
            //System.out.println("travelMode : "+travelMode);

            place = scan.next().toUpperCase();
            //System.out.println("place : "+place);

            distance = scan.nextInt();
            //System.out.println("distance: "+distance);

            accomodationType = scan.next();
            //System.out.println("accomodationType : "+accomodationType);
            //System.out.println("===================");

            Travel travel = new Travel(duration, capitalizeAccommodation, cost, travelers, travelMode, place, distance, accomodationType); 
            travelList.add(travel);
        }
    }
    
    /**
     * This method return the list of places names that contains vowles or consonents in the travel object
     */
    public void vowlesOrConsonents(){
        Iterator<Travel> travelIterator = travelList.iterator();
        LinkedList<String> v = new LinkedList<String>();
        LinkedList<String> c = new LinkedList<String>();
        int i = 0;
        while(travelIterator.hasNext()){
            Travel obj = travelIterator.next();
            String place = obj.getPlace();
            for(int x = 0; x < place.length(); x++){
                char ch = place.charAt(x);
                if(ch == 'A' || ch == 'E' || ch == 'I'
                    || ch == 'O' || ch == 'U') {
                    v.add(place);
                    //stringStatistics.put("vowles", place);
                    //vowles.add(vowlesOrConsonents);
                }
                if(place.matches("[QWRTYPSDFGHJKLZXCVBNM]+")){
                    c.add(place);
                }
            }
            i++;
            stringStatistics.put("vowles", v);
            stringStatistics.put("consonents", c);
        }
    }
    
    /**
     * This method returns the string which has "hotel" as a pattern in the stay name of travel object
     */
    public void hasHotelInName(){
        Iterator<Travel> travelIterator = travelList.iterator();
        
        int i = 0;
        while(travelIterator.hasNext()){
            String mode = travelIterator.next().getAccomodation();
            if(mode.contains("Hotel"))
                startsWithHotel.add(mode);
        }
    }
    
    /**
     * This method returns the string which has "N" as a pattern at the end of the place string
     */
    public void stringEndsWithN(){
        Iterator<Travel> travelIterator = travelList.iterator();
        
        int i = 0;
        while(travelIterator.hasNext()){
            String endsWithN = travelIterator.next().getPlace();
            //System.out.println("endsWithN : "+ endsWithN);
            if(endsWithN.endsWith("N"))
                endsWithNList.add(endsWithN);
            i++;
        }
    }
    
    /**
     * This method returns the string which has travel mode as 'Flight' 
     */
    public void placesWithTravelModeFlight(){//travelModeFlight
        Iterator<Travel> travelIterator = travelList.iterator();
        
        int i = 0;
        while(travelIterator.hasNext()){
            Travel travelObj = travelIterator.next();
            String travelMode = travelObj.getTravelMode();
            String place = travelObj.getPlace();
            //System.out.println("endsWithN : "+ endsWithN);
            if(travelMode.equals("flight"))
                travelModeFlight.add(place);
            i++;
        }
    }

    /**
     * @param word
     * This method returns the vowles string objects
     * @return array of string vowles
     */
    public LinkedList<String> getVowles(String word) {
        return stringStatistics.get(word);
    }

    /**
     * @param word
     * This method returns consonents string objects
     * @return array of string consonents
     */
    public LinkedList<String> getConsonents(String word) {
        return stringStatistics.get(word);
    }
    
    /**
     * This method returns list of stay which has "hotels" as a pattern
     * @return startsWithHotel
     */
    public Set<String> getListWithHotelString() {
        return startsWithHotel;
    }
    
    /**
     * This method returns list of stay which ends with char 'u' at the end
     * @return endsWithUList
     */
    public Set<String> getStringsEndingWithN() {
        return endsWithNList;
    }
    
    /**
     * This method returns list of stay which ends with char 'u' at the end
     * @return endsWithUList
     */
    public Set<String> getplacesWithTravelModeFlight() {
        return travelModeFlight;
    }
    
    /**
     * This method takes the string as an input the Converts the first character of every work to uppercase
     * @param input takes string as an input
     * @return capitalized string
     */
    public String toCapitalizeString(String input) {
        String[] arr = input.split(" ");
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < arr.length; i++) {
            sb.append(Character.toUpperCase(arr[i].charAt(0)))
                .append(arr[i].substring(1)).append(" ");
        }          
        return sb.toString().trim();
    }
    
    /**
     * This is a customized print statement with gives the details of the travel plan
     * @return String(travel plan)
     */
    public String travelSummary() {
        String print = "";
        print += "*****************************   Travel Itinerary   *****************************\n";
        //print += "Destination: Bali";
        Iterator<Travel> myItr = travelList.iterator();
        
        while(myItr.hasNext()) {
            print += myItr.next() + "\n";
            //System.out.println(travel);
        }
        print += "\n********************************************************************************\n";
        return print;
    }
    
    
    
}
