/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mapSetList;

import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeMap;

/**
 *
 * @author "Soujanya Janapatla";
 */
public class ItineraryDriver {
    
    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException FileOutput exception
     */
    public static void main(String[] args) throws FileNotFoundException{
        // TODO code application logic here
        Itinerary travelItinerary = new Itinerary();
        
        //System.out.println("Hello!");
        travelItinerary.addLocations();
        System.out.println(travelItinerary.travelSummary());
        System.out.println("*****************************   String Manipulations   *****************************");
        System.out.println("String containing Vowles: ");
        travelItinerary.vowlesOrConsonents();
        System.out.println(travelItinerary.getVowles("vowles"));
        System.out.println("String containing Consonents");
        System.out.println(travelItinerary.getConsonents("consonents"));
        System.out.println("Places starts with 'Hotel': ");
        travelItinerary.hasHotelInName();
        System.out.println(travelItinerary.getListWithHotelString());
        System.out.println("Place name ends with 'N'");
        travelItinerary.stringEndsWithN();
        System.out.println(travelItinerary.getStringsEndingWithN());
        System.out.println("Place with travel mode 'flight'");
        travelItinerary.placesWithTravelModeFlight();
        System.out.println(travelItinerary.getplacesWithTravelModeFlight());
        System.out.println("********************************************************************************");
    }
    
    
    
}
