/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mapSetList;

/**
 *
 * @author "Soujanya Janapatla";
 */
public class Travel {
    private int duration; //How many days spent visiting
    private int numberOfTravelers; //count of travelers
    private double cost;
    private String travelMode; //travelMode by road or ferry or train or car
    private String place; //Location name
    private int distance; //distance from the airport
    private String accomodation; //Accomodation
    private String accomodationType; //Single, Couple, Family
    
    /**
     * Constructor set the initial values of the travel itinerary
     */    
    public Travel() {
        this.duration = 0;
        this.numberOfTravelers = 0;
        this.cost = 0.0;
        this.travelMode = "";
        this.place = "";
        this.distance = 0;
        this.accomodation = "";
        this.accomodationType = "";
    }

    /**
     * Parameterized constructor which overrides the default values of the Travel Itinerary
     * @param duration duration
     * @param numberOfTravelers numberOfTravelers
     * @param cost cost
     * @param travelMode travelMode
     * @param place place
     * @param distance distance
     * @param accomodation accommodation
     * @param accomodationType accomodationType
     */
    public Travel(
            int duration,
            String accomodation,
            double cost,
            int numberOfTravelers,
            String travelMode,
            String place,
            int distance,
            String accomodationType
    ) {
        this.duration = duration;
        this.numberOfTravelers = numberOfTravelers;
        this.cost = cost;
        this.travelMode = travelMode;
        this.place = place;
        this.distance = distance;
        this.accomodation = accomodation;
        this.accomodationType = accomodationType;
    }

    /**
     * This method returns the time spent at a locations
     * @return duration days
     */
    public int getDuration() {
        return duration;
    }

    /**
     * This method sets the time spent at a location
     * @param duration time spent for visit
     */
    public void setDuration(int duration) {
        this.duration = duration;
    }

    /**
     * This method get the count of people traveling
     * @return numberOfTravelers
     */
    public int getNumberOfTravelers() {
        return numberOfTravelers;
    }

    /**
     * This method sets the number of people planning to travel 
     * @param numberOfTravelers people joining the visit
     */
    public void setNumberOfTravelers(int numberOfTravelers) {
        this.numberOfTravelers = numberOfTravelers;
    }

    /**
     * This method returns the cost of the accommodation
     * @return cost
     */
    public double getCost() {
        return cost;
    }

    /**
     * this method sets the cost of the accommodation at a location
     * @param cost amount for rent
     */
    public void setCost(double cost) {
        this.cost = cost;
    }

    /**
     * This method return the travel mode
     * @return travelMode
     */
    public String getTravelMode() {
        return travelMode;
    }

    /**
     * This method sets the travel mode ["On Road", "By train", "By flight", etc..]
     * @param travelMode either on road/ train/ferry/flight
     */
    public void setTravelMode(String travelMode) {
        this.travelMode = travelMode;
    }

    /**
     * This method return the location name
     * @return place
     */
    public String getPlace() {
        return place;
    }

    /**
     * This method sets the location name
     * @param place name of the location
     */
    public void setPlace(String place) {
        this.place = place;
    }

    /**
     * This method returns the distance between the places
     * @return distance
     */
    public int getDistance() {
        return distance;
    }

    /**
     * This method sets the distance between the places
     * @param distance distance to reach a certain place
     */
    public void setDistance(int distance) {
        this.distance = distance;
    }

    /**
     * This method returns the accommodation or stay name
     * @return accomodation
     */
    public String getAccomodation() {
        return accomodation;
    }

    /**
     * This method sets the accommodation or stay name
     * @param accomodation hotel to stay at
     */
    public void setAccomodation(String accomodation) {
        this.accomodation = accomodation;
    }

    /**
     * This method returns the accommodation type 
     * @return accomodationType Single, Couple, Family
     */
    public String getAccomodationType() {
        return accomodationType;
    }

    /**
     * This method sets the accommodation type Single, Couple, Family
     * @param accomodationType Single, Couple, Family
     */
    public void setAccomodationType(String accomodationType) {
        this.accomodationType = accomodationType;
    }

    /**
     * This method prints the Itinerary summary for the objects in the Itinerary 
     * @return result Itinerary summary
     */
    @Override
    public String toString() {
        String result = "";
        result += "\nNumber of Travelers : " + numberOfTravelers;
        result += "\nPlace : " + place + "\t\tTravel Mode : " + travelMode + "\tPlace Cost : $" + cost;
        result += "\nStay : " + accomodation + "\t\tAccomodation Type : " + accomodationType + "\tDistance: " + distance + "km";
        return result;
    }
    
    
}

