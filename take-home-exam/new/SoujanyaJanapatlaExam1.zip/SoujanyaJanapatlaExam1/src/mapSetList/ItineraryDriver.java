/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mapSetList;

import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeMap;

/**
 *
 * @author "Soujanya Janapatla";
 */
public class ItineraryDriver {
    
    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException FileOutput exception
     */
    public static void main(String[] args) throws FileNotFoundException{
        // TODO code application logic here
        Itinerary travelItinerary = new Itinerary();
        
        //System.out.println("Hello!");
        travelItinerary.addLocations();
        System.out.println(travelItinerary.travelSummary());
        System.out.println("*****************************   String Statistics   *****************************");
        System.out.println("String containing Vowles alone : ");
        travelItinerary.findVowlesAndConsonents();
        System.out.println(travelItinerary.getVowles("vowles"));
        System.out.println("String containing Consonents alone :");
        System.out.println(travelItinerary.getConsonents("consonents"));
        System.out.println("Places starts with 'Hotel': ");
        travelItinerary.hasHotelInName();
        System.out.println(travelItinerary.getListWithHotelString("hotel"));
        System.out.println("Place name ends with 'N' :");
        travelItinerary.stringEndsWithN();
        System.out.println(travelItinerary.getStringsEndingWithN("n"));
        System.out.println("Place with travel mode 'flight' :");
        travelItinerary.placesWithTravelModeFlight();
        System.out.println(travelItinerary.getplacesWithTravelModeFlight("flight"));
        System.out.println("\n*****************************   String Manipulations   *****************************\n");
        System.out.println("Capitalizing the Stay parameter: ");
        travelItinerary.capitalizeString();
        System.out.println(travelItinerary.getStringCapitalized("capitalize"));
        System.out.println("Transform place names to fancy letters: ");
        travelItinerary.facyLetters();
        System.out.println(travelItinerary.getFancyString("underscore"));
        System.out.println("Add currency to stay cost per day");
        travelItinerary.setStayCostWithUnits();
        System.out.println(travelItinerary.getStayCostWithUnits("dollar"));
        System.out.println("add units to distance");
        travelItinerary.addUnitsToDistance();
        System.out.println(travelItinerary.getUnitsToDistance("km"));
        
    }   
}
