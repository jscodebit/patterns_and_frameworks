/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mapSetList;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author "Soujanya Janapatla";
 */
public class Itinerary {
    private LinkedList<Travel> travelList;
    Set<Travel> formattedList = new HashSet<Travel>();
    //LinkedList<String> vowles = new LinkedList<String>();
    LinkedList<String> vowlesOnly = new LinkedList<String>();    
    LinkedList<String> consonentsOnly = new LinkedList<String>();
    LinkedList<String> startsWithHotel = new LinkedList<String>();
    LinkedList<String> endsWithNList = new LinkedList<String>();//
    LinkedList<String> travelModeFlight = new LinkedList<String>();
    public static TreeMap<String, LinkedList<String>> stringStatistics = new TreeMap<String, LinkedList<String>>();

    /**
     * No parameter constructor for Itinerary class initializing the LinedList of type Travel
     */
    public Itinerary() {
        this.travelList = new LinkedList<Travel>();
    }
    
    /**
     * Since this class perform file input output its recommended to use Exception handlers
     * @throws FileNotFoundException Input Exception
     */
    public void addLocations()throws FileNotFoundException {
        //System.out.println("Hi");
        Scanner scan = new Scanner(new File("itinerary.txt"));
        int duration, distance,travelers; //How much time can be spent to look around
        double cost;
        String destination, place, description, accomodation, accomodationType, stayCostPerday, activity, food, travelMode, numberOfTravelers, temp, placeOne, placeTwo; //Location name
        String capitalizeAccommodation;
        while(scan.hasNext()){
            duration = scan.nextInt();
            placeOne = scan.next();
            placeTwo = scan.next();
            accomodation = placeOne.concat(" ")+placeTwo;
            capitalizeAccommodation = accomodation;
            cost = scan.nextDouble();
            numberOfTravelers = scan.next();
            temp = numberOfTravelers.replace("daycount", "");
            travelers = Integer.parseInt(temp);
            travelMode = scan.next();
            place = scan.next().toUpperCase();
            distance = scan.nextInt();
            accomodationType = scan.next();

            Travel travel = new Travel(duration, capitalizeAccommodation, cost, travelers, travelMode, place, distance, accomodationType); 
            travelList.add(travel);
        }
    }
    
    /**
     * This method return the list of places names that contains vowles or consonents in the travel object
     */
    public void findVowlesAndConsonents() {
        
        Iterator<Travel> travelIterator = travelList.iterator();
        LinkedList<String> placeNames = new LinkedList<>();
        
        while(travelIterator.hasNext()){
            String placeName = travelIterator.next().getPlace();
            //System.out.println("Place name : "+ placeNames);
            placeNames.add(placeName);
        }
        
        HashSet<Character> hash = new HashSet<Character>();
        // To store vowels 
  
        // Outer loop picks starting character and 
        // inner loop picks ending character.
        
        Iterator<String> name = placeNames.iterator();
        while(name.hasNext()){
            String str = name.next();
            int n = str.length(); 
            
            for (int i = 0; i < n; i++) { 
                for (int j = i; j < n; j++) { 
                    if (isVowel(str.charAt(j)) == false) {
                        //hashTwo.add(str);
                        break;
                    } 
                    // If vowel, then we insert it in hash 
                    hash.add(str.charAt(j));
                } 
            }
            if(hash.size() == 0){
                consonentsOnly.add(str);    
                //System.out.println("Trialll : "+ hash + "String : "+ str);
            } else if(hash.size() == 5){
                // If all vowels are present in current 
                vowlesOnly.add(str);
            }
            hash.clear();
        }
        stringStatistics.put("vowles", vowlesOnly);        
        stringStatistics.put("consonents", consonentsOnly);

        //System.out.println("stringStatistics : "+ stringStatistics.size());
        //System.out.println(stringStatistics.keySet());
    }
    
    
    // Returns true if x is vowel. 
    public static boolean isVowel(char x) { 
        // Function to check whether a character is 
        // vowel or not 
        return (x == 'a' || x == 'e' || x == 'i' 
                || x == 'o' || x == 'u' || x == 'A' || x == 'E' || x == 'I' 
                || x == 'O' || x == 'U'); 
    }
    
    /**
     * This method returns the string which has "hotel" as a pattern in the stay name of travel object
     */
    public void hasHotelInName(){
        Iterator<Travel> travelIterator = travelList.iterator();
        
        int i = 0;
        while(travelIterator.hasNext()){
            String mode = travelIterator.next().getAccomodation();
            if(mode.contains("hotel"))
                startsWithHotel.add(mode);
                
        }
        stringStatistics.put("hotel", startsWithHotel);
    }
    
    /**
     * This method returns the string which has "N" as a pattern at the end of the place string
     */
    public void stringEndsWithN(){
        Iterator<Travel> travelIterator = travelList.iterator();
        
        int i = 0;
        while(travelIterator.hasNext()){
            String endsWithN = travelIterator.next().getPlace();
            //System.out.println("endsWithN : "+ endsWithN);
            if(endsWithN.endsWith("N"))
                endsWithNList.add(endsWithN);
            i++;
        }
        stringStatistics.put("n", endsWithNList);
    }
    
    /**
     * This method returns the string which has travel mode as 'Flight' 
     */
    public void placesWithTravelModeFlight(){//travelModeFlight
        Iterator<Travel> travelIterator = travelList.iterator();
        
        while(travelIterator.hasNext()){
            Travel travelObj = travelIterator.next();
            String travelMode = travelObj.getTravelMode();
            String place = travelObj.getPlace();
            //System.out.println("endsWithN : "+ endsWithN);
            if(travelMode.equals("flight"))
                travelModeFlight.add(place);
        }
        stringStatistics.put("flight", travelModeFlight);
    }

    /**
     * @param word
     * This method returns the vowles string objects
     * @return array of string vowles
     */
    public LinkedList<String> getVowles(String word) {
        return stringStatistics.get(word);
    }

    /**
     * @param word
     * This method returns consonents string objects
     * @return array of string consonents
     */
    public LinkedList<String> getConsonents(String word) {
        return stringStatistics.get(word);
    }
    
    /**
     * @param word hotel
     * This method returns list of stay which has "hotels" as a pattern
     * @return startsWithHotel
     */
    public LinkedList<String> getListWithHotelString(String word) {
        return stringStatistics.get(word);
    } 
    
    /**
     * @param word letter n
     * This method returns list of stay which ends with char 'u' at the end
     * @return endsWithUList
     */
    public LinkedList<String> getStringsEndingWithN(String word) {
        return stringStatistics.get(word);
    }
    
    /**
     * @param word flight
     * This method returns list of stay which ends with char 'u' at the end
     * @return endsWithUList
     */
    public LinkedList<String> getplacesWithTravelModeFlight(String word) {
        return stringStatistics.get(word);
    }
    
    /**
     * This method takes the string as an input the Converts the first character of every work to uppercase
     * @param input takes string as an input
     * @return capitalized string
     */
    public String toCapitalizeString(String input) {
        String[] arr = input.split(" ");
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < arr.length; i++) {
            sb.append(Character.toUpperCase(arr[i].charAt(0)))
                .append(arr[i].substring(1)).append(" ");
        }          
        return sb.toString().trim();
    }
    
    public void capitalizeString(){
        Iterator<Travel> travelIterator = travelList.iterator();
        LinkedList<String> placeNames = new LinkedList<>();
        
        while(travelIterator.hasNext()){
            String acc = travelIterator.next().getAccomodation();
            //System.out.println("Place name : "+ placeNames);
            placeNames.add(toCapitalizeString(acc));
        }
        stringStatistics.put("capitalize", placeNames);        
    }
    
    /**
     * This method returns list place names in a fancy format
     */
    public void facyLetters(){
        Iterator<Travel> travelIterator = travelList.iterator();
        LinkedList<String> placeNames = new LinkedList<>();
        
        while(travelIterator.hasNext()){
            String place = travelIterator.next().getAccomodation();
            //System.out.println("Place name : "+ placeNames);
            placeNames.add(place.replaceAll(" ", "_"));
        }
        stringStatistics.put("underscore", placeNames);         
    }
    
    /**
     * This method returns list of stay cost with units
     */
    public void setStayCostWithUnits(){
        Iterator<Travel> travelIterator = travelList.iterator();
        LinkedList<String> costWithUnits = new LinkedList<>();
        
        while(travelIterator.hasNext()){
            String cost = String.valueOf(travelIterator.next().getCost());
            //String str = String.valueOf(dnum); 
            //System.out.println("Place name : "+ placeNames);
            String unit = "$";
            costWithUnits.add(unit.concat(cost));
        }
        stringStatistics.put("dollar", costWithUnits);         
    }
    
        public void addUnitsToDistance(){
        Iterator<Travel> travelIterator = travelList.iterator();
        LinkedList<String> costWithUnits = new LinkedList<>();
        
        while(travelIterator.hasNext()){
            String distance = String.valueOf(travelIterator.next().getDistance());
            //String str = String.valueOf(dnum); 
            //System.out.println("Place name : "+ placeNames);
            String unit = "km";
            costWithUnits.add(distance.concat(unit));
        }
        stringStatistics.put("km", costWithUnits);         
    }
        
    /**
     * @param word Hello World
     * This method returns list of stay capitalized
     * @return capitalized string
     */
    public LinkedList<String> getStringCapitalized(String word) {
        return stringStatistics.get(word);
    }
    /**
     * @param word $20.33
     * This method returns list of stay cost with $ in the beginning
     * @return $cost
     */
    public LinkedList<String> getStayCostWithUnits(String word) {
        return stringStatistics.get(word);
    }
    
    /**
     * @param word Hello_World
     * This method returns list of stay and replaces space with underscore
     * @return words replaced with underscore
     */
    public LinkedList<String> getFancyString(String word) {
        return stringStatistics.get(word);
    }
    
    /**
     * @param word 200km
     * This method returns list of stay and replaces space with underscore
     * @return distance in km
     */
    public LinkedList<String> getUnitsToDistance(String word) {
        return stringStatistics.get(word);
    }
    
    /**
     * This is a customized print statement with gives the details of the travel plan
     * @return String(travel plan)
     */
    public String travelSummary() {
        String print = "";
        print += "*****************************   Travel Itinerary   *****************************\n";
        //print += "Destination: Bali";
        Iterator<Travel> myItr = travelList.iterator();
        
        while(myItr.hasNext()) {
            print += myItr.next() + "\n";
            //System.out.println(travel);
        }
        print += "\n********************************************************************************\n";
        return print;
    }
    
    
    
}
