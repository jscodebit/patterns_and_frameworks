/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackQueueHash;

import java.util.ArrayDeque;
import java.util.Iterator;

/**
 *
 * @author "Soujanya Janapatla";
 */
class AStack<E> {
    private ArrayDeque<E> cardStack;

    public AStack() {
        cardStack = new ArrayDeque<E>();
    }
    
    /**
     * Method to insert elements to Stack
     *
     * @param element parameter of type E
     */
    public void push(E element) {
        cardStack.push(element);
    }

    /**
     * Method to remove elements from stack
     *
     * @return returns elements of type E
     */
    public E pop() {
        return cardStack.pop();
    }

    /**
     * Method that retrieves/read the top element in stack
     *
     * @return element of type E
     */
    public E peek() {
        return cardStack.peek();
    }

    /**
     * Method that gives stack size
     *
     * @return size of type int
     */
    public int size() {
        return cardStack.size();
    }

    /**
     * Method to know if stack is empty or not
     *
     * @return Boolean value
     */
    public boolean isEmpty() {
        return cardStack.isEmpty();
    }

    /**
     * Iterator over each item/element from the stack
     * @return elements of type iterator
     */
    public Iterator<E> iterator() {
        return cardStack.iterator();
    }
}
