/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackQueueHash;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.LinkedBlockingQueue;

/**
 *
 * @author "Soujanya Janapatla";
 */
public class PlayerDriver {

    /**
     * Since the class includes file reading operation it might throw some exception
     * @param args all the inputs
     * @throws FileNotFoundException exception
     */
    public static void main(String args[]) throws FileNotFoundException{
        //Declare and initialize a scanner object to read from the file "inputFile.txt"
        int capacity = 10, playerCount = 1, gameRounds = 3;
        int[] playerScore = new int[capacity];
        Scanner myScanner = new Scanner(new File("cardInputFile.txt"));
        AStack<Card> cards = new AStack<Card>();
        TreeMap<String,Integer> scoreDetails = new TreeMap<String,Integer>();
        
        LinkedBlockingQueue<Player> queue = new LinkedBlockingQueue<Player>(capacity);
	
        //While inputFile.txt has more data(While loop starts here) {
        while(myScanner.hasNext()){
            //Read in the data
            int number = myScanner.nextInt();
            myScanner.nextLine();
            String suite = myScanner.nextLine();
            
            Card card = new Card(number, suite);
            //Add the card object to CardsArray object
            cards.push(card);
        }
        
        //Adds the player to the queue
        while(queue.remainingCapacity()!= 0){
            queue.add(new Player("Player "+ playerCount));
            playerCount++;
        }
        //Gives the details of the Players and the card picked in the game rounds
        System.out.println("\n============= Cards Picked by Players =============");
        for (int i = 0; i < gameRounds; i++) {
            System.out.println("------------------ Game Round "+(i+1)+" -------------------\n");
            drawCradsFromDeck(queue, cards, scoreDetails);
        }
        System.out.println("------------------- End of Rounds -------------------\n");
        LinkedHashMap<String, Integer> sortedMap = sortByValue(scoreDetails);
        
        //System.out.println("Final size "+ sortedMap.size());
        System.out.println("================= Final Ranked List =================\n");
        //System.out.println("Final Ranked List of players along with score: ");
        // Get a set of the entries
        Set newSet = sortedMap.entrySet();

        // Iterate through the list from Descending order
        Iterator sortedList = newSet.iterator();
        //System.out.println(sortedList.s);

        // Display elements
        while(sortedList.hasNext()) {
            Map.Entry record = (Map.Entry)sortedList.next();
            System.out.print(record.getKey() + "\t");
            System.out.println("Score : "+record.getValue());
            //System.out.println(iterate);
        } 
    }
    
    /**
     * This method takes player object(LinkedList), Card stack and TreeMap to store the score and details of the player
     * @param queue collection of players
     * @param cards collection of cards in stack
     * @param scoreDetails score details of players
     */
    public static void drawCradsFromDeck(LinkedBlockingQueue<Player> queue, AStack<Card> cards, TreeMap<String, Integer> scoreDetails){
        //System.out.println("Player size : "+queue.size());
        Iterator<Player> player = queue.iterator();
        
        while(player.hasNext()){
            Player person = player.next();
            Card c = cards.pop();
            Integer score = scoreDetails.get(person.getName());
            if(score == null){
                addScore(scoreDetails, person.getName(), c.getNumber());
            } else {
                Integer scoreTemp = scoreDetails.get(person.getName()) + c.getNumber();
                //System.out.println(person.getName()+" "+scoreTemp);
                scoreDetails.put(person.getName(), scoreTemp);
            }
            System.out.println("Player Name: "+person.getName()+"\t ID: "+person.getId() +" \nCard value: "+c.getNumber()+"\t Card type: "+c.getSuit()+"\tScore : "+ scoreDetails.get(person.getName())+"\n");//
        }
    }
    
    /**
     * Method adds the score card every time the player picks the card
     * @param scoreList TreeMap object
     * @param name String
     * @param score Integer
     */
    public static void addScore(TreeMap<String, Integer> scoreList, String name, Integer score){
        scoreList.put(name, score);
    }
    
    /**
     * This function sorts the TreeMap from high to low score
     * @param unsortedMap object to store collection
     * @return sortedMap from highest score to lowest
     */
    public static LinkedHashMap<String, Integer> sortByValue(TreeMap<String, Integer> unsortedMap) {
        //System.out.println("UnSorted Map Size : "+unsortedMap.size());
        
        LinkedHashMap<String, Integer> reverseSortedMap = new LinkedHashMap<>();
        unsortedMap.entrySet().stream().sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .forEachOrdered(x -> reverseSortedMap.put(x.getKey(), x.getValue()));
        //System.out.println("Sorted Map "+ reverseSortedMap.size());
        return reverseSortedMap;
    }  
}


