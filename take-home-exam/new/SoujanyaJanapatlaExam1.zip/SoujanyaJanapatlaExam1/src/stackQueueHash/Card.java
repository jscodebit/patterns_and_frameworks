/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackQueueHash;

/**
 *
 * @author "Soujanya Janapatla";
 */
public class Card {
    /**
     * Instant variables number and suit[Heart, Spade, Diamond, club]
     **/
    private int number;
    private String suit;

    /**
     * Defining a parameterized constructor which sets number and suit type
     * @param number 1-13
     * @param suit [Heart, Spade, Diamond, club]
     */
    public Card(int number, String suit) {
        this.number = number;
        this.suit = suit;
    }

    /**
     * This method returns number on the card
     * @return number the value on the card
     */
    public int getNumber() {
        return number;
    }

    /**
     * This method sets the number of the card 
     * @param number get the value for the card
     */
    public void setNumber(int number) {
        this.number = number;
    }

    /**
     * This method returns suit type mentioned on the card
     * @return [Heart, Spade, Diamond, club]
     */
    public String getSuit() {
        return suit;
    }

    /**
     * This method sets the suit [Heart, Spade, Diamond, club] on the card
     * @param suit String
     */
    public void setSuit(String suit) {
        this.suit = suit;
    }

    /**
     * This method prints the details of the card like number and suit type
     * @return result suit and number
     */
    @Override
    public String toString() {
        String result = this.suit +" "+this.number;
        return result;
    }  
}
