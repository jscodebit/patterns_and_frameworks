/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackQueueHash;

import java.util.Objects;

/**
 *
 * @author "Soujanya Janapatla";
 */
public class Player {
    /**
     * Instance variables of Player Class 
     **/
    private String name;
    private int id;

    /**
     * Parameterized constructor for Player name
     * @param name Player 1/ Player 2...
     */
    public Player(String name){
        this.name = name;
        this.id = new Hashifier(name).hashCode();
    }

    /**
     * Method returns the name of the player
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Method returns the id of the player
     * @return id
     */
    public int getId() {
        return id;
    }
    
    /**
     * Generates a hashCode(ID) for every Player
     **/
    private static class Hashifier {
        private String seed;
        
        /**
         * Parameterized constructor with name  
         **/
        public Hashifier(String name) {
            this.seed = name;
        }

        public String getSeed() {
            return seed;
        }
        
        /**
         * Generates a hashCode and return its value
         **/
        @Override
        public int hashCode() {
            int hash = 7;
            hash = 53 * hash + Objects.hashCode(this.seed);
            return hash;
        }
        
        /**
         * ToString function to print the variables details
         **/
        @Override
        public String toString() {
            return "Hashifier{" + "seed=" + seed + '}';
        }
        
        /**
         * Overriding the equals method 
         */
        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final Hashifier other = (Hashifier) obj;
            return true;
        }   
    }
}
