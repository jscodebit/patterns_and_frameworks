/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stacksanddeques;


/**
 *
 * @author "Soujanya Janapatla";
 */
public class GreetingsStack {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    AStack<Character> greet = new AStack<Character>();
        char Array[] = new char[100];
        greet.push('H');greet.push('a');greet.push('p');greet.push('p');greet.push('y');greet.push(' ');
        greet.push('N');greet.push('e');greet.push('w');greet.push(' ');
        greet.push('Y');greet.push('e');greet.push('a');greet.push('r');
        for(int i = greet.size(); i>0;i--){
            Array[i]=greet.pop();
            
        }
        System.out.println(Array);
    }
}
