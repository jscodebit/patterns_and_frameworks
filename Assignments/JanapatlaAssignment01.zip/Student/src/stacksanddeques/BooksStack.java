/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stacksanddeques;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author "Soujanya Janapatla";
 */
public class BooksStack {

    /**
     *
     * @param args
     * @throws FileNotFoundException
     */
    public static void main(String args[]) throws FileNotFoundException{
        AStack<Book> bookList = new AStack<Book>();
        Scanner scan = new Scanner(new File("books.txt"));
        
        System.out.println("All books in the stack from top to bottom");
        System.out.println("-------------------------------------");
        while(scan.hasNext()){
            String book = scan.nextLine();
            String author = scan.nextLine();
            bookList.push(new Book(book, author));
        }
        
        Iterator<Book> bookIterator = bookList.iterator();
        while (bookIterator.hasNext()) {
            Book print = bookIterator.next();
            System.out.println(print);
            System.out.println("-------------------------------------");
        }
        
        System.out.println();
        System.out.println();
        System.out.println("Stack after removing book with name Fantastic Beasts: The Crimes of Grindelwald");
        System.out.println("-------------------------------------");
        
        Iterator<Book> bookIterator1 = bookList.iterator();
        while (bookIterator1.hasNext()) {
            Book bk1 = bookIterator1.next();
            if (bk1.getTitle().contains("Fantastic Beasts: The Crimes of Grindelwald")) {
                bookList.pop();
            } else {
                System.out.println(bk1);
                System.out.println("-------------------------------------");
            }
        }
        System.out.println();        
    }
    
}
