/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedlist;

import java.util.LinkedList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Set;

/**
 *
 * @author "Soujanya Janapatla";
 */
public class StudentOperations {
    private LinkedList<Student> studentList; 
    HashSet<Student> StudentSet = new HashSet<Student>();

    /**
     *
     */
    public StudentOperations() {
        studentList = new LinkedList<Student>();
    }

    /**
     *
     * @throws FileNotFoundException
     */
    public void addStudents() throws FileNotFoundException{
        //studentList.add();
        Scanner scan = new Scanner(new File("input.txt"));
        while(scan.hasNext()){
            String name = scan.next() +" "+scan.next();
            int id = scan.nextInt();
            //scan.next();
            //SSystem.out.println("name: "+name+" id: "+id);
            studentList.add(new Student(name, id));
        }
    }
    
    /**
     *
     */
    public void removeDuplicates(){
        ListIterator<Student> myIteratorForSets = studentList.listIterator();
        while(myIteratorForSets.hasNext()){
            StudentSet.add(myIteratorForSets.next());
            //System.out.println(myIteratorForSets.next());
        }
        studentList = new LinkedList<Student>(StudentSet);
    }
    
    /**
     *
     * @param studentList
     * @return
     */
    public String displayDuplicatesNamesByRecursion(Iterator<Student> studentList){
        String result= "";
        HashSet<Student> setToReturn = new HashSet<Student>(); 
        HashSet<Student> set1 = new HashSet<Student>();
        //System.out.println("Hello");
        StringBuilder names = new StringBuilder();
        
        while (studentList.hasNext()) {
            Student st =  studentList.next();
            if (set1.contains(st)) {
                setToReturn.add(st);
            } else {
                set1.add(st);
            }
        }

        for (Student s : setToReturn) {
            names.append(s.getName()).append(", ");
        }
        
//        Iterator<Student> i = setToReturn.iterator(); 
//        while (i.hasNext()) {
//            result += i.next().getName()+ ", "; 
//        }
        
        return names.toString();
    }

    /**
     *
     * @return
     */
    public LinkedList<Student> getStudentList() {
        return studentList;
    }

    /**
     *
     * @return
     */
    public HashSet<Student> getStudentSet() {
        return StudentSet;
    }
    
}
