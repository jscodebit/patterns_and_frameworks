/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queue;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author "Soujanya Janapatla";
 */
public class LinkedDriver {
    Queue<Integer> myQ = new LinkedList<>();
    
    /**
     *
     * @param args
     * @throws InterruptedException
     */
    public static void main(String[] args) throws InterruptedException {
        int capacity = 5;
        LinkedBlockingQueue<Integer> queue = new LinkedBlockingQueue<Integer>(capacity);
        queue.add(5);
        System.out.println("Inserted one element, remaining capacity: " + queue.remainingCapacity());
        queue.add(2);
        System.out.println("Inserted two elements, remaining capacity: " + queue.remainingCapacity());
        queue.add(2);
        System.out.println("Inserted three elements, remaining capacity: " + queue.remainingCapacity());
        queue.add(3);
        System.out.println("Inserted four elements, remaining capacity: " + queue.remainingCapacity());
        queue.add(3);
        System.out.println("Inserted five elements, remaining capacity: " + queue.remainingCapacity());
        System.out.println();
        System.out.println("Trying to insert 6th element using offer() :");
        System.out.println(queue.offer(6, 5, TimeUnit.SECONDS));
        System.out.println();
        System.out.println("Trying to insert 6th element using add()");
        try {
            System.out.println(queue.add(6));
        } catch (Exception e) {
            System.out.println("Exception : " + e);

        }
        System.out.println();
        System.out.println("By using offer method to add 6th element waiting for time interval of"
                + " 5 seconds, a boolean value is returned as False " + "\n"
                + "By using add method, it throws an exception saying Queue is full");
        System.out.println();
        System.out.println("Displaying duplicate elements: ");
        Iterator<Integer> itr = queue.iterator();
        Set<Integer> originalSet = new HashSet();
        Set<Integer> duplicateSet = new HashSet();
        while (itr.hasNext()) {
            Integer i = itr.next();
            if (originalSet.contains(i)) {
                duplicateSet.add(i);
            } else {
                originalSet.add(i);
            }
        }

        for (Integer b : duplicateSet) {
            System.out.println(b);
        }
        System.out.println();
        System.out.println("Invoking poll() and remove() methods :");
        System.out.println(queue.poll());
        System.out.println(queue.remove());
        System.out.println();
        System.out.println("Making queue object empty :");
        queue.removeAll(queue);
        System.out.println(queue);
        System.out.println();
        System.out.println("Invoking peek() and element() methods :");
        System.out.println(queue.peek());
        try {
            System.out.println(queue.element());
        } catch (Exception e) {
            System.out.println("Exception : " + e);
        }
        System.out.println();
        System.out.println("poll() method returns and eliminate the head of the queue which is '5', and returns null when queue is empty.");
        System.out.println("remove() method retrieved and eliminate the head of the queue which is element '2'");
        System.out.println();
        System.out.println("Emptied the queue object");
        System.out.println();
        System.out.println("peek() method displayed 'null' because the queue object is empty, othwewise will retrieve the head of the queue");
        System.out.println("element() method gave 'NoSuchElementException' since the queue is empty ");

    }
}
